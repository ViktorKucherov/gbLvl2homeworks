package gb2.less1.obstacles;

import gb2.less1.participants.Participant;

public interface Obstacle {

    boolean passIt(Participant p);
}
